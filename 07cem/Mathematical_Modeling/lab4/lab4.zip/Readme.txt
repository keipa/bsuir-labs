Python3
for correct work install module down below

pip install goto_statement