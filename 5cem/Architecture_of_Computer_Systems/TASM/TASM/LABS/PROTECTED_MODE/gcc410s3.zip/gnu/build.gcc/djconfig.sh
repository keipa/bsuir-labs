#! /bin/sh

src=../gcc-4.10
export TEST_FINDS_EXE=Y
export PATH_SEPARATOR=:
target=djgpp
export AS=as.exe
export LD=ld.exe
export NM=nm.exe
export CC=gcc
export ac_cv_func_mmap_dev_zero=no
export lt_cv_sys_max_cmd_len=12000
export ac_cv_prog_LN='cp -p'
export ac_cv_prog_LN_S='cp -p'
CONFIG_SHELL=`/bin/sh -c 'echo $0'`
case $CONFIG_SHELL in *.exe) ;; *) CONFIG_SHELL=$CONFIG_SHELL.exe ;; esac
export CONFIG_SHELL
#
if ! grep -q __builtin_va_list $DJDIR/include/sys/djtypes.h ; then
   echo "Your DJGPP installation have old incompatible $DJDIR/include/sys/djtypes.h"
   echo "Please apply patch for this file included at end of `(cd ..; pwd)`/readme.DJGPP"
   exit 1
fi
#
conf_options="$target --prefix=/dev/env/DJDIR --disable-nls --disable-werror"
conf_options="$conf_options --enable-languages=c++"
#
srcdir=`(cd $src && pwd) | sed -e 's,^[a-zA-Z]:/,/,' -e 's,^/dev/[a-zA-Z]/,/,'`
builddir=`pwd | sed -e 's,^[a-zA-Z]:/,/,' -e 's,^/dev/[a-zA-Z]/,/,'`
#
echo "Configuring GCC ..."
echo "Source directory : $srcdir"
echo "Build directory : $builddir"
#
$srcdir/configure $conf_options $*
