﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interpreter.frontend.pascal
{
    public class PascalToken : Token
    {
        protected PascalToken(Source source) : base(source)
        {
        }
    }
}
